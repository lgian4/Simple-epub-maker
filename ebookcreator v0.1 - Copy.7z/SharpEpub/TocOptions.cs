﻿namespace SharpEpub
{
	public enum TocOptions
	{
		ByFilename = 0,
		ByTitleTag
	}
}
