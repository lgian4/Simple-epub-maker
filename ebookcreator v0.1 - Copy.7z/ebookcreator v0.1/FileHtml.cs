﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Windows.Forms;
using Aspose.Html;
using SharpEpub;
using SharpEpub.XmlBuilder;
namespace ebookcreator_v0._1

{
    class FileHtml : Chapter

    {
        public FileHtml(string code, int no, string title, string chapter) : base(code, no, title, chapter)
        {

        }

        public static void makexhtml(string realtitle, Array chapter, string dir, string title, string alttitle, string author, string translator, string editor, string status, string raw, string synopsis, string lang, string note, string link)
        {
            dir = (Application.StartupPath + "\\output\\" + realtitle + "\\chapter" + chapter.GetValue(0) + "-" + chapter.GetValue(chapter.Length - 1));
            Directory.CreateDirectory(dir);
            string code = "";
            Array judul = realtitle.Split();
            foreach (string b in judul)
            {
                code += (b.Substring(0, 1).ToLower());
            }

            EpubOnFly epub = new EpubOnFly();
            epub.Metadata.Creator = author;
            epub.Metadata.Date = DateTime.Now.ToShortDateString();
            epub.Metadata.Description = synopsis + "\n<br/>" + note + "\n<br/> BY : " + translator;
            epub.Metadata.Language = lang;
            epub.Metadata.Publisher = "Linargian Pratama";
            epub.Metadata.Source = link;
            epub.Metadata.Subject = "Web Novel";
            epub.Metadata.Title = title + " Chapter : " + chapter.GetValue(0) + "-" + chapter.GetValue(chapter.Length - 1);
            epub.Structure.Directories.ImageFolder = "Image";
            epub.AddImage("cover.jpg", System.IO.File.ReadAllBytes(Application.StartupPath + "\\novel\\" + code + "\\cover\\cover.jpg"));
            epub.Structure.Directories.CssFolder = "Styles";
            epub.AddCss("style.css", System.IO.File.ReadAllText(Application.StartupPath + "\\bahan\\OEBPS\\Styles\\style.css"));
            epub.AddResource("//Fonts//", "literata-bold-italic.otf", System.IO.File.ReadAllBytes(Application.StartupPath + "\\bahan\\OEBPS\\Fonts\\literata-bold-italic.otf"));
            epub.AddResource("//Fonts//", "literata-regular.otf", System.IO.File.ReadAllBytes(Application.StartupPath + "\\bahan\\OEBPS\\Fonts\\literata-regular.otf"));
            epub.TableOfContents.BookTitle = title +" Chapter : " + chapter.GetValue(0) + "-" + chapter.GetValue(chapter.Length - 1);

            epub.Structure.Directories.ContentFolder = "Text";


            var isicover = @"<!DOCTYPE html><html ><head><title>Title</title><link href='../Styles/style.css' type='text/css' rel='stylesheet'/></head><body><div class='cover'><h1>" + title + "<h6>(" + alttitle + ")</h6>" + "</h1> - <h2>" + author + "</h2><br/><h2> Chapter : " + chapter.GetValue(0) + " - " + chapter.GetValue(chapter.Length - 1) + "</h2></div>  <div style='text-align: center; padding: 0pt; margin: 0pt;'>";


            isicover += @"</div></body></html>";

            var isicover1 = @"<!DOCTYPE html><html ><head><title>Cover</title><link href='../Styles/style.css' type='text/css' rel='stylesheet'/></head><body><div class='cover1'><h1>" + title + "</h1> - <h2>" + author + "</h2><br/><h2> Chapter : " + chapter.GetValue(0) + " - " + chapter.GetValue(chapter.Length - 1) + "</h2></div>  <div style='text-align: center; padding: 0pt; margin: 0pt;'>";
            isicover1 = @"<img src='../OPS/Image/cover.jpg'></img>";

            isicover1 += @"</div></body></html>";
            var copyright = @"<!DOCTYPE html><html ><head><title>CopyRight</title><link href='../Styles/style.css' type='text/css' rel='stylesheet'/></head><body><div><h1>Copyright</h1> <hr><p>All rights reserved.</p><p><br /></p><p>English Translation by the " + translator + " at <a href='" + link + "'>" + link + "</a>.</p><p><br /></p><p>ePub conversion by Linargian Pratama @ <a href='#'>Lazy Epub</a></p><p><br /></p><p>This is a free eBook. You are free to give it away (in unmodified form) to whomever you wish.</p><p><br /></p><p>No part of this eBook may be reproduced or transmitted in any form or by any means, electronic or mechanical, including photocopying, recording or by any information storage and retrieval system, without written permission from the author.</p><p><br /></p><p>This book is a work of fiction. Names, characters, places, and incidents either are products of the author's imagination or are used fictitiously. Any resemblance to actual persons, living or dead, events, or locales is entirely coincidental.</p></div>  <div style='text-align: center; padding: 0pt; margin: 0pt;'>";


            copyright += @"</div></body></html>";
            var synop = @"<!DOCTYPE html><html ><head><title>Synopsis</title><link href='../Styles/style.css' type='text/css' rel='stylesheet'/></head><body><div class='cover'><h1>Synopsis</h1> <hr> <p>" + synopsis + "</p><br/><p>NOTE : <br/> " + note + "</p></div>  <div style='text-align: center; padding: 0pt; margin: 0pt;'>";


            synop += @"</div></body></html>";


            epub.AddContent("cover.html", isicover1);
            epub.AddContent("cover1.html", isicover);
            epub.AddContent("copyright.html", copyright);
            epub.AddContent("Synopsys.html", synop);




            var isi = Chapter.dapatisichapter(realtitle);
            int a = 0;

            string[] filechapter = new string[chapter.Length];
            string[] titlechapter = new string[chapter.Length];
            foreach (string item in chapter)
            {
                var b = isi.Select(" no ='" + item + "'", " no ASC");

                String outputHtml = dir + "\\OEBPS\\Text\\" + realtitle + "-" + item + ".xhtml";


                var document = new HTMLDocument();


                string heading = @"<!DOCTYPE html><html><head><title>" + b[0][1] + "</title><link href='../OPS/Styles/style.css' type='text/css' rel='stylesheet'/></head><body><h1>Chapter :" + b[0][0].ToString() + " " + b[0][1].ToString() + "</h1><hr>";
                // Byte[] v  = Convert.FromBase64String(b[0][2].ToString());
                // UTF8Encoding.Convert(Encoding.Unicode,Encoding.UTF8, v);
                var content = "<br/>" + b[0][2].ToString().Replace("’", "'") + "</p></body></html>";
                titlechapter[a] = "Chapter " + item + " - " + b[0][1].ToString();
                filechapter[a] = outputHtml;
                epub.AddContent(item + ".html", heading + content);







                a++;
            }
            epub.BuildToFile(dir + @"\" + realtitle + ".epub");










        }
        public static string adjustcontent(string isi)
        {
            Char[] abjkecil = "qwertyuiopasdfghjklzxcvbnm".ToCharArray();
            Char[] abjbesar = "QWERTYUIOPASDFGHJKLZXCVBNM".ToCharArray();
            Char[] ank = "1234567890@`#$%^&*()_+|\\=-}{[]\"\'<;:>/".ToCharArray();
            //hilangin enter berlebihan
            isi = isi.Replace("\n\n", "\n");
            isi = isi.Replace("\n\n\n", "\n");
            isi = isi.Replace("\n\n\n\n", "\n");
            isi = isi.Replace("\n\n\n\n\n", "\n");
            isi = isi.Replace("\n\n\n\n\n\n", "\n");

            // menghilangkan tab berlebihan
            isi = isi.Replace("\t\t", "\t");
            isi = isi.Replace("\t\t\t", "\t");
            isi = isi.Replace("\t\t\t\t", "\t");

            // menganti tanda petik
            isi = isi.Replace("”", "\"");
            isi = isi.Replace("“", "\"");

            // enter ke titk
            isi = isi.Replace(".\"\"", ".\"\n\"");
            isi = isi.Replace(". ", ".\n");
            for (int i = 0; i <= abjbesar.Length - 1; i++)
            {
                isi = isi.Replace("." + abjkecil[i], ".\n" + abjbesar[i]);
            }
            for (int i = 0; i <= abjbesar.Length - 1; i++)
            {
                isi = isi.Replace("." + abjbesar[i], ".\n" + abjbesar[i]);
            }
            for (int i = 0; i <= abjbesar.Length - 1; i++)
            {
                isi = isi.Replace("." + ank[i], ".\n" + ank[i]);
            }
            // tanda tanya
            isi = isi.Replace("?\"\"", "?\"\n\"");
            isi = isi.Replace("? ", "?\n");
            for (int i = 0; i <= abjbesar.Length - 1; i++)
            {
                isi = isi.Replace("?" + abjkecil[i], "?\n" + abjbesar[i]);
            }
            for (int i = 0; i <= abjbesar.Length - 1; i++)
            {
                isi = isi.Replace("?" + abjbesar[i], "?\n" + abjbesar[i]);
            }
            for (int i = 0; i <= abjbesar.Length - 1; i++)
            {
                isi = isi.Replace("?" + ank[i], "?\n" + ank[i]);
            }
            // tanda seru
            isi = isi.Replace("!\"\"", "!\"\n\"");
            isi = isi.Replace("! ", "!\n");
            for (int i = 0; i <= abjbesar.Length - 1; i++)
            {
                isi = isi.Replace("!" + abjkecil[i], "!\n" + abjbesar[i]);
            }
            for (int i = 0; i <= abjbesar.Length - 1; i++)
            {
                isi = isi.Replace("!" + abjbesar[i], "!\n" + abjbesar[i]);
            }
            for (int i = 0; i <= abjbesar.Length - 1; i++)
            {
                isi = isi.Replace("!" + ank[i], "!\n" + ank[i]);
            }


            isi = isi.Replace("\"\"", "\"\t\"");
            isi = isi.Replace(@"–", "-");

            isi = isi.Replace(",", ", ");
            isi = isi.Replace("’", "'");
            isi = isi.Replace("‘", "'");
            
            isi = isi.Replace("\n", "<br/><br/>");
            return isi;
        }

        public static string openfile(string dir)
        {
            String InputHtml = dir;
            // Create HtmlDocument instance to load existing HTML file
            Aspose.Html.HTMLDocument document = new Aspose.Html.HTMLDocument(InputHtml);

            // Print inner HTML of file to console
            var isi = document.Body.TextContent;
            isi = adjustcontent(isi);


            var title = document.Title;


            //var isi = chaptercontent.InnerHTML;

            return title + "\t\t" + isi;
        }
    }
}
