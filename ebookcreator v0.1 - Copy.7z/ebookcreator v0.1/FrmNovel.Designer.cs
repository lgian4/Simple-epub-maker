﻿namespace ebookcreator_v0._1
{
    partial class FrmNovel
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.panel1 = new System.Windows.Forms.Panel();
            this.txtlink = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.txtnote = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.txtlang = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.button2 = new System.Windows.Forms.Button();
            this.txtcover = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.txtsynopsis = new System.Windows.Forms.TextBox();
            this.txtraw = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.txtstatus = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.txteditor = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.txttrans = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.txtauthor = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.txtalt = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.txttitle = new System.Windows.Forms.TextBox();
            this.lblcode = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.cmdcancel = new System.Windows.Forms.Button();
            this.cmdconfirm = new System.Windows.Forms.Button();
            this.cmddelete = new System.Windows.Forms.Button();
            this.cmdupdate = new System.Windows.Forms.Button();
            this.cmdinsert = new System.Windows.Forms.Button();
            this.erp1 = new System.Windows.Forms.ErrorProvider(this.components);
            this.panel3 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.dg1 = new System.Windows.Forms.DataGridView();
            this.panel4 = new System.Windows.Forms.Panel();
            this.panel5 = new System.Windows.Forms.Panel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.bsc1 = new System.Windows.Forms.BindingSource(this.components);
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.erp1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dg1)).BeginInit();
            this.panel4.SuspendLayout();
            this.panel5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bsc1)).BeginInit();
            this.SuspendLayout();
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "openFileDialog1";
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.txtlink);
            this.panel1.Controls.Add(this.label8);
            this.panel1.Controls.Add(this.txtnote);
            this.panel1.Controls.Add(this.label14);
            this.panel1.Controls.Add(this.txtlang);
            this.panel1.Controls.Add(this.label13);
            this.panel1.Controls.Add(this.button2);
            this.panel1.Controls.Add(this.txtcover);
            this.panel1.Controls.Add(this.label12);
            this.panel1.Controls.Add(this.txtsynopsis);
            this.panel1.Controls.Add(this.txtraw);
            this.panel1.Controls.Add(this.label6);
            this.panel1.Controls.Add(this.txtstatus);
            this.panel1.Controls.Add(this.label11);
            this.panel1.Controls.Add(this.txteditor);
            this.panel1.Controls.Add(this.label5);
            this.panel1.Controls.Add(this.txttrans);
            this.panel1.Controls.Add(this.label4);
            this.panel1.Controls.Add(this.txtauthor);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.txtalt);
            this.panel1.Controls.Add(this.label10);
            this.panel1.Controls.Add(this.label7);
            this.panel1.Controls.Add(this.button1);
            this.panel1.Controls.Add(this.txttitle);
            this.panel1.Controls.Add(this.lblcode);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.cmdcancel);
            this.panel1.Controls.Add(this.cmdconfirm);
            this.panel1.Controls.Add(this.cmddelete);
            this.panel1.Controls.Add(this.cmdupdate);
            this.panel1.Controls.Add(this.cmdinsert);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel1.Location = new System.Drawing.Point(0, 26);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(279, 648);
            this.panel1.TabIndex = 30;
            // 
            // txtlink
            // 
            this.txtlink.Location = new System.Drawing.Point(76, 472);
            this.txtlink.Name = "txtlink";
            this.txtlink.Size = new System.Drawing.Size(193, 20);
            this.txtlink.TabIndex = 56;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(12, 475);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(27, 13);
            this.label8.TabIndex = 55;
            this.label8.Text = "Link";
            // 
            // txtnote
            // 
            this.txtnote.Location = new System.Drawing.Point(76, 391);
            this.txtnote.Multiline = true;
            this.txtnote.Name = "txtnote";
            this.txtnote.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtnote.Size = new System.Drawing.Size(193, 75);
            this.txtnote.TabIndex = 54;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(12, 394);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(30, 13);
            this.label14.TabIndex = 53;
            this.label14.Text = "Note";
            // 
            // txtlang
            // 
            this.txtlang.Location = new System.Drawing.Point(76, 364);
            this.txtlang.Name = "txtlang";
            this.txtlang.Size = new System.Drawing.Size(193, 20);
            this.txtlang.TabIndex = 52;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(12, 367);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(55, 13);
            this.label13.TabIndex = 51;
            this.label13.Text = "Language";
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(194, 333);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(75, 23);
            this.button2.TabIndex = 50;
            this.button2.Text = "Pilih";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // txtcover
            // 
            this.txtcover.Enabled = false;
            this.txtcover.Location = new System.Drawing.Point(76, 333);
            this.txtcover.Name = "txtcover";
            this.txtcover.Size = new System.Drawing.Size(112, 20);
            this.txtcover.TabIndex = 49;
            this.txtcover.TextChanged += new System.EventHandler(this.txtcover_TextChanged);
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(12, 336);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(35, 13);
            this.label12.TabIndex = 48;
            this.label12.Text = "Cover";
            // 
            // txtsynopsis
            // 
            this.txtsynopsis.Location = new System.Drawing.Point(76, 250);
            this.txtsynopsis.MaxLength = 99999999;
            this.txtsynopsis.Multiline = true;
            this.txtsynopsis.Name = "txtsynopsis";
            this.txtsynopsis.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtsynopsis.Size = new System.Drawing.Size(193, 75);
            this.txtsynopsis.TabIndex = 47;
            // 
            // txtraw
            // 
            this.txtraw.Location = new System.Drawing.Point(76, 220);
            this.txtraw.Name = "txtraw";
            this.txtraw.Size = new System.Drawing.Size(193, 20);
            this.txtraw.TabIndex = 46;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(12, 223);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(29, 13);
            this.label6.TabIndex = 45;
            this.label6.Text = "Raw";
            // 
            // txtstatus
            // 
            this.txtstatus.Location = new System.Drawing.Point(76, 194);
            this.txtstatus.Name = "txtstatus";
            this.txtstatus.Size = new System.Drawing.Size(193, 20);
            this.txtstatus.TabIndex = 44;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(12, 197);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(37, 13);
            this.label11.TabIndex = 43;
            this.label11.Text = "Status";
            // 
            // txteditor
            // 
            this.txteditor.Location = new System.Drawing.Point(76, 169);
            this.txteditor.Name = "txteditor";
            this.txteditor.Size = new System.Drawing.Size(193, 20);
            this.txteditor.TabIndex = 42;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(12, 172);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(34, 13);
            this.label5.TabIndex = 41;
            this.label5.Text = "Editor";
            // 
            // txttrans
            // 
            this.txttrans.Location = new System.Drawing.Point(76, 140);
            this.txttrans.Name = "txttrans";
            this.txttrans.Size = new System.Drawing.Size(193, 20);
            this.txttrans.TabIndex = 40;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(12, 143);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(54, 13);
            this.label4.TabIndex = 39;
            this.label4.Text = "Translator";
            // 
            // txtauthor
            // 
            this.txtauthor.Location = new System.Drawing.Point(76, 114);
            this.txtauthor.Name = "txtauthor";
            this.txtauthor.Size = new System.Drawing.Size(193, 20);
            this.txtauthor.TabIndex = 38;
            this.txtauthor.TextChanged += new System.EventHandler(this.textBox2_TextChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(12, 117);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(38, 13);
            this.label2.TabIndex = 37;
            this.label2.Text = "Author";
            // 
            // txtalt
            // 
            this.txtalt.Location = new System.Drawing.Point(76, 85);
            this.txtalt.Name = "txtalt";
            this.txtalt.Size = new System.Drawing.Size(193, 20);
            this.txtalt.TabIndex = 36;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(12, 88);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(57, 13);
            this.label10.TabIndex = 35;
            this.label10.Text = "Alternative";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(12, 253);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(46, 13);
            this.label7.TabIndex = 29;
            this.label7.Text = "Sinopsis";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(203, 597);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(72, 52);
            this.button1.TabIndex = 21;
            this.button1.Text = "Back";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click_1);
            // 
            // txttitle
            // 
            this.txttitle.Location = new System.Drawing.Point(76, 59);
            this.txttitle.Name = "txttitle";
            this.txttitle.Size = new System.Drawing.Size(193, 20);
            this.txttitle.TabIndex = 18;
            this.txttitle.TextChanged += new System.EventHandler(this.txttitle_TextChanged);
            // 
            // lblcode
            // 
            this.lblcode.BackColor = System.Drawing.Color.White;
            this.lblcode.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblcode.Location = new System.Drawing.Point(76, 25);
            this.lblcode.Name = "lblcode";
            this.lblcode.Size = new System.Drawing.Size(193, 20);
            this.lblcode.TabIndex = 15;
            this.lblcode.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(12, 62);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(27, 13);
            this.label3.TabIndex = 17;
            this.label3.Text = "Title";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 29);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(32, 13);
            this.label1.TabIndex = 14;
            this.label1.Text = "Code";
            // 
            // cmdcancel
            // 
            this.cmdcancel.Enabled = false;
            this.cmdcancel.Location = new System.Drawing.Point(106, 626);
            this.cmdcancel.Name = "cmdcancel";
            this.cmdcancel.Size = new System.Drawing.Size(91, 23);
            this.cmdcancel.TabIndex = 13;
            this.cmdcancel.Text = "Cancel";
            this.cmdcancel.UseVisualStyleBackColor = true;
            this.cmdcancel.Click += new System.EventHandler(this.cmdcancel_Click);
            // 
            // cmdconfirm
            // 
            this.cmdconfirm.Enabled = false;
            this.cmdconfirm.Location = new System.Drawing.Point(8, 626);
            this.cmdconfirm.Name = "cmdconfirm";
            this.cmdconfirm.Size = new System.Drawing.Size(92, 23);
            this.cmdconfirm.TabIndex = 12;
            this.cmdconfirm.Text = "Confirm";
            this.cmdconfirm.UseVisualStyleBackColor = true;
            this.cmdconfirm.Click += new System.EventHandler(this.cmdconfirm_Click);
            // 
            // cmddelete
            // 
            this.cmddelete.Location = new System.Drawing.Point(143, 597);
            this.cmddelete.Name = "cmddelete";
            this.cmddelete.Size = new System.Drawing.Size(55, 23);
            this.cmddelete.TabIndex = 11;
            this.cmddelete.Text = "Delete";
            this.cmddelete.UseVisualStyleBackColor = true;
            this.cmddelete.Click += new System.EventHandler(this.cmddelete_Click);
            // 
            // cmdupdate
            // 
            this.cmdupdate.Location = new System.Drawing.Point(74, 597);
            this.cmdupdate.Name = "cmdupdate";
            this.cmdupdate.Size = new System.Drawing.Size(63, 23);
            this.cmdupdate.TabIndex = 10;
            this.cmdupdate.Text = "Update";
            this.cmdupdate.UseVisualStyleBackColor = true;
            this.cmdupdate.Click += new System.EventHandler(this.cmdupdate_Click);
            // 
            // cmdinsert
            // 
            this.cmdinsert.Location = new System.Drawing.Point(8, 597);
            this.cmdinsert.Name = "cmdinsert";
            this.cmdinsert.Size = new System.Drawing.Size(60, 23);
            this.cmdinsert.TabIndex = 9;
            this.cmdinsert.Text = "Insert";
            this.cmdinsert.UseVisualStyleBackColor = true;
            this.cmdinsert.Click += new System.EventHandler(this.cmdinsert_Click);
            // 
            // erp1
            // 
            this.erp1.ContainerControl = this;
            // 
            // panel3
            // 
            this.panel3.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel3.Location = new System.Drawing.Point(0, 674);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(930, 21);
            this.panel3.TabIndex = 17;
            // 
            // panel2
            // 
            this.panel2.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel2.Location = new System.Drawing.Point(0, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(930, 26);
            this.panel2.TabIndex = 16;
            // 
            // dg1
            // 
            this.dg1.AllowUserToAddRows = false;
            this.dg1.AllowUserToDeleteRows = false;
            this.dg1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dg1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dg1.Location = new System.Drawing.Point(279, 26);
            this.dg1.MultiSelect = false;
            this.dg1.Name = "dg1";
            this.dg1.ReadOnly = true;
            this.dg1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dg1.Size = new System.Drawing.Size(651, 648);
            this.dg1.TabIndex = 19;
            this.dg1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dg1_CellContentClick);
            this.dg1.SelectionChanged += new System.EventHandler(this.dg1_SelectionChanged);
            // 
            // panel4
            // 
            this.panel4.Controls.Add(this.panel5);
            this.panel4.Dock = System.Windows.Forms.DockStyle.Right;
            this.panel4.Location = new System.Drawing.Point(930, 0);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(234, 695);
            this.panel4.TabIndex = 18;
            // 
            // panel5
            // 
            this.panel5.Controls.Add(this.pictureBox1);
            this.panel5.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel5.Location = new System.Drawing.Point(0, 0);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(234, 255);
            this.panel5.TabIndex = 1;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBox1.Location = new System.Drawing.Point(0, 0);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(234, 255);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // FrmNovel
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1164, 695);
            this.ControlBox = false;
            this.Controls.Add(this.dg1);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel4);
            this.Name = "FrmNovel";
            this.Text = "Novel";
            this.Load += new System.EventHandler(this.FrmNovel_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.erp1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dg1)).EndInit();
            this.panel4.ResumeLayout(false);
            this.panel5.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bsc1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.OpenFileDialog openFileDialog1;
        private System.Windows.Forms.BindingSource bsc1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox txttitle;
        private System.Windows.Forms.Label lblcode;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button cmdcancel;
        private System.Windows.Forms.Button cmdconfirm;
        private System.Windows.Forms.Button cmddelete;
        private System.Windows.Forms.Button cmdupdate;
        private System.Windows.Forms.Button cmdinsert;
        private System.Windows.Forms.ErrorProvider erp1;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.DataGridView dg1;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.TextBox txtauthor;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtalt;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox txtlink;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox txtnote;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox txtlang;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.TextBox txtcover;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox txtsynopsis;
        private System.Windows.Forms.TextBox txtraw;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txtstatus;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox txteditor;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txttrans;
        private System.Windows.Forms.Label label4;
    }
}