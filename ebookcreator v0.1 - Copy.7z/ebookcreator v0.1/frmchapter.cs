﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ebookcreator_v0._1
{
    
    public partial class frmchapter : Form
    {
        string func;          
        public frmchapter()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form1 a = new Form1();
            a.Show();
            this.Close();
        }
        private void start()
        {
            if (dg1.RowCount <= 0) { cmdupdate.Enabled = true; }
            cmddelete.Enabled = true;
            dg1.Enabled = true;
            cmdinsert.Enabled = true;
            
            cmdcancel.Enabled = false;
            cmdconfirm.Enabled = false;
            bsc1.DataSource = Chapter.select();
            dg1.DataSource = bsc1;
            isilbl();

        }
        public void isilbl()
        {
            try
            {
                cmdupdate.Enabled = true;
                cmddelete.Enabled = true;

                lblid.Text = System.Convert.ToString(dg1.CurrentRow.Cells[0].Value);
                cbocode.SelectedText = System.Convert.ToString(dg1.CurrentRow.Cells[1].Value);
                txttitle.Text = System.Convert.ToString(dg1.CurrentRow.Cells[3].Value);
                txtno.Text = System.Convert.ToString(dg1.CurrentRow.Cells[2].Value);
                rtxchapter.Text = System.Convert.ToString(dg1.CurrentRow.Cells[4].Value);
                txtfile.Text = System.Convert.ToString(dg1.CurrentRow.Cells[5].Value);
                
                
            }
            catch
            {
            }
        }
        private void frmchapter_Load(object sender, EventArgs e)
        {
            start();
            foreach (string a in Chapter.dapatcode()) { cbocode.Items.Add(a); }
        }

        private void cmdinsert_Click(object sender, EventArgs e)
        {
            func = "I";
            cmddelete.Enabled = false;
            cmdupdate.Enabled = false;
            cmdinsert.Enabled = false;
            cmdconfirm.Enabled = true;
            cmdcancel.Enabled = true;
            dg1.Enabled = false;
            rtxchapter.Text = "";
            txttitle.Text = "";
            lblid.Text = "";
            txtno.Text = "";
            txtfile.Text = "";

           
        }

        private void cmdupdate_Click(object sender, EventArgs e)
        {
            isilbl();
            func = "U";
            cmddelete.Enabled = false;
            cmdupdate.Enabled = false;
            cmdinsert.Enabled = false;
            cmdconfirm.Enabled = true;
            cmdcancel.Enabled = true;
            dg1.Enabled = false;
            
        }

        private void cmdconfirm_Click(object sender, EventArgs e)
        {
            Chapter chapter = new Chapter(cbocode.Text,Convert.ToInt32(txtno.Text),txttitle.Text,rtxchapter.Text, lblid.Text);
            chapter.aksidata(func);
            start();
        }

        private void cmddelete_Click(object sender, EventArgs e)
        {
            DialogResult dr = new DialogResult();
            dr = MessageBox.Show("Delete", "Are You Sure ?", MessageBoxButtons.OKCancel, MessageBoxIcon.Warning);
            if (dr == DialogResult.OK) Chapter.deletedata(Convert.ToInt32( lblid.Text));
        }

        private void dg1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            isilbl();
        }

        private void dg1_SelectionChanged(object sender, EventArgs e)
        {
            isilbl();
        }

        private void cbocode_SelectedIndexChanged(object sender, EventArgs e)
        {
           
        }

        private void button2_Click(object sender, EventArgs e)
        {
            rtxchapter.Text = FileHtml.adjustcontent(rtxchapter.Text);
        }
    }
}
