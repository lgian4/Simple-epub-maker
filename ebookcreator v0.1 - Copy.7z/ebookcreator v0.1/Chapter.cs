﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Windows.Forms;
using System.Data.OleDb;
using System.IO;
using System.Collections;
namespace ebookcreator_v0._1
{
    class Chapter
    {
        private int _id;

        public int Id
        {
            get { return _id; }
            set { _id = value; }
        }
        private String _code;

        public String codeNovel
        {
            get { return _code; }
            set
            {
                if (value.Trim() == "")
                {
                    _code= "NaN";
                }
                else {_code = value.Trim(); }
            }
        }
        private int _no;

        public int No
        {
            get { return _no; }
            set
            {
              
                if (value <= 0 )
                {
                   _no   = 0;
                }
                else { _no = value; }
            }
        }
        private string _title;

        public string Title
        {
            get { return _title; }
            set
            {
                if (value.Trim() == "")
                {
                   _title = "NaN";
                }
                else {_title= value.Trim(); }
            }
        }
        private string _chapter;

        public string cHapter
        {
            get { return _chapter; }
            set
            {
                if (value.Trim() == "")
                {
                    _chapter = "NaN";
                }
                else {_chapter = value.Trim(); }
            }
        }
        public Chapter( string code, int no, string title, string chapter, string id = "")
        {
            if (id == "")
            {
                conn = new OleDbConnection(koneksistring);
                conn.Open();
                comm = new OleDbCommand();
                comm.Connection = conn;
                string query = "SELECT  * FROM  tblchapter ORDER BY id DESC";

                comm.CommandText = query;
                reader = comm.ExecuteReader();
                if (reader.HasRows == false)
                {

                    Id = 1;
                }
                else
                {
                    reader.Read();
                    Id = Convert.ToInt32(reader.GetValue(0)) + 1;

                }
                reader.Close();
                conn.Close();
            }
            else {
                Id = Convert.ToInt32( id);
            }
            codeNovel = code;
            No = no;
            Title = title;
            cHapter = chapter;
        }
        private string _file;

        public string File
        {
            get { return _file; }
            set { _file = value; }
        }

        public static DataTable select()
        {
            Novel.conn = new OleDbConnection(Novel.koneksistring);
            Novel.conn.Open();
            Novel.comm = new OleDbCommand();
            Novel.comm.Connection = Novel.conn;
            Novel.comm.CommandText = "SELECT * FROM  tblchapter";
            Novel.reader = Novel.comm.ExecuteReader();
            if (Novel.reader.HasRows == false)
            {
                MessageBox.Show("table  is empty");

            }
            else
            {
                Novel.reader.Close();
                Novel.adap = new OleDbDataAdapter(Novel.comm);
                Novel.tabel = new DataTable();
                Novel.adap.Fill(Novel.tabel);

            }
            Novel.conn.Close();
            return Novel.tabel;
        }
        private static string _koneksistring = "provider=microsoft.ace.oledb.12.0.0; data source=" + Application.StartupPath + "//epub1.accdb";
        internal static OleDbConnection conn = new OleDbConnection();
        internal static OleDbCommand comm = new OleDbCommand();
        internal static OleDbDataAdapter adap = new OleDbDataAdapter();
        internal static OleDbDataReader reader;
        internal static DataTable tabel = new DataTable();

        internal static string koneksistring { get { return _koneksistring; } }
        public static ArrayList dapatcode()
        {

           conn = new OleDbConnection(koneksistring);
            conn.Open();
            comm = new OleDbCommand();
            comm.Connection = conn;
            string query = "SELECT  * FROM  tblnovel  ";
            ArrayList lCode = new ArrayList();
            comm.CommandText = query;
            reader = comm.ExecuteReader();
            if (reader.HasRows == false)
            {

                lCode = null;
            }
            else
            {
                while (reader.Read())
                    
                { 
                   
                   lCode.Add( reader.GetValue(0) );
                }
         
            }
            reader.Close();
            conn.Close();
            return lCode;
        }
        public static ArrayList dapatjudul()
        {

            conn = new OleDbConnection(koneksistring);
            conn.Open();
            comm = new OleDbCommand();
            comm.Connection = conn;
            string query = "SELECT  * FROM  tblnovel  ";
            ArrayList lCode = new ArrayList();
            comm.CommandText = query;
            reader = comm.ExecuteReader();
            if (reader.HasRows == false)
            {

                lCode = null;
            }
            else
            {
                while (reader.Read())

                {

                    lCode.Add(reader.GetValue(1));
                }

            }
            reader.Close();
            conn.Close();
            return lCode;
        }
        public static ArrayList dapatchapter(string title)
        {
          
            
            conn = new OleDbConnection(koneksistring);
            conn.Open();
            comm = new OleDbCommand();
            comm.Connection = conn;
            string query = "SELECT  tblchapter.no FROM  tblchapter inner join tblnovel on tblchapter.codenovel = tblnovel.code WHERE tblnovel.title = '"+title+"' ORDER BY tblchapter.no ASC";
            ArrayList lCode = new ArrayList();
            comm.CommandText = query;
            reader = comm.ExecuteReader();
            if (reader.HasRows == false)
            {

                lCode = null;
            }
            else
            {
                while (reader.Read())

                {

                    lCode.Add(reader.GetValue(0));
                }

            }
            reader.Close();
            conn.Close();
            return lCode;
        }
        public static DataTable   dapatisichapter(string title)
        {

            Novel.conn = new OleDbConnection(Novel.koneksistring);
            Novel.conn.Open();
            Novel.comm = new OleDbCommand();
            Novel.comm.Connection = Novel.conn;
            Novel.comm.CommandText = "SELECT  tblchapter.no, tblchapter.title, tblchapter.chapter FROM  tblchapter inner join tblnovel on tblchapter.codenovel = tblnovel.code WHERE tblnovel.title = '" + title + "' ORDER BY tblchapter.no ASC";
            Novel.reader = Novel.comm.ExecuteReader();
            if (Novel.reader.HasRows == false)
            {
                MessageBox.Show("table  is empty");

            }
            else
            {
                Novel.reader.Close();
                Novel.adap = new OleDbDataAdapter(Novel.comm);
                Novel.tabel = new DataTable();
                Novel.adap.Fill(Novel.tabel);

            }
            Novel.conn.Close();
            return Novel.tabel;

           
           
        }
        public static void deletedata(int id)
        {
            OleDbConnection conn = new OleDbConnection(Novel.koneksistring);
            conn.Open();
            OleDbCommand comm = new OleDbCommand();
            comm.Connection = conn;

            comm.CommandText = "DELETE FROM tblchapter WHERE id = " + id;

            comm.ExecuteScalar();

            conn.Close();
        }
        public void aksidata(string func)
        {

            OleDbParameter pid = new OleDbParameter("@id", OleDbType.Integer);
            OleDbParameter pcodenovel = new OleDbParameter("@codenovel", OleDbType.VarChar);
            OleDbParameter pno = new OleDbParameter("@no", OleDbType.Integer);
            OleDbParameter ptitle = new OleDbParameter("@ptitle", OleDbType.VarChar);
            OleDbParameter pchapter = new OleDbParameter("@chapter", OleDbType.VarChar);
            pid.Value = Id;
            ptitle.Value = Title;
            pcodenovel.Value = codeNovel;
            pno.Value = No;
            ptitle.Value = Title;
            pchapter.Value = cHapter;
            
            

            OleDbConnection conn = new OleDbConnection(koneksistring);
            conn.Open();
            OleDbCommand comm = new OleDbCommand();
            comm.Connection = conn;
            if (func == "I")
            {

                comm.CommandText = "INSERT INTO tblchapter Values(@id,@codenovel,@no,@title,@chapter,'')";
                comm.Parameters.Add(pid);
                comm.Parameters.Add(pcodenovel);
                comm.Parameters.Add(pno);
                comm.Parameters.Add(ptitle);
                comm.Parameters.Add(pchapter);



            }
            else
            {

                comm.CommandText = @"UPDATE tblchapter SET tblchapter.codenovel = @codenovel, tblchapter.[no] =@no, tblchapter.title=@title,tblchapter.chapter=@chapter  WHERE (((tblchapter.id) = @id));";
               
                comm.Parameters.Add(pcodenovel);
                comm.Parameters.Add(pno);
                comm.Parameters.Add(ptitle);
                comm.Parameters.Add(pchapter);
                comm.Parameters.Add(pid);

            }
            MessageBox.Show(comm.ExecuteNonQuery().ToString() + "Row Chenged");

            conn.Close();
        }


    }
}
