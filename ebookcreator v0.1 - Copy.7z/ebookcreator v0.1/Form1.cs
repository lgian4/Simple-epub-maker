﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
namespace ebookcreator_v0._1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            
        }

        private void openToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FrmNovel fnovel = new FrmNovel();
            fnovel.Show();
            this.Hide();
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void openToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            frmchapter fnovel = new frmchapter();
            fnovel.Show();
            this.Hide();
        }

        private void extractHtmlToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FrmExtractHtml fextract = new FrmExtractHtml();
            fextract.Show();
            Hide();
        }

        private void openToolStripMenuItem2_Click(object sender, EventArgs e)
        {
            FrmMakeEpub fepub = new FrmMakeEpub();
            fepub.Show();
            Hide();
        }
    }
}
