﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Collections;
namespace ebookcreator_v0._1
{
    public partial class FrmMakeEpub : Form
    {
        public FrmMakeEpub()
        {
            InitializeComponent();
        }

        private void FrmMakeEpub_Load(object sender, EventArgs e)
        {
            foreach (string a in Chapter.dapatjudul()) { cbotitle.Items.Add(a); }
            cbotitle.SelectedIndex = 0;
            isicho();
        }

        private void cbotitle_SelectedIndexChanged(object sender, EventArgs e)
        {

            var isi = Chapter.dapatchapter(cbotitle.Text);
            cboch1.Items.Clear();
            cboch2.Items.Clear();
            if (isi != null)
            {
                foreach (string a in isi)
                {

                    cboch1.Items.Add(a);
                    cboch1.SelectedIndex = 0;
                    cboch2.Items.Add(a);
                    cboch2.SelectedIndex = cboch2.Items.Count - 1;

                }
                isilbl();
            }



        }
        public void isilbl()
        {
            var isi = Novel.select();
            for (int i = 0; i <= isi.Rows.Count; i++)
            {
                if (isi.Rows[i][1].ToString() == cbotitle.Text)
                {
                    txttitle.Text = isi.Rows[i][1].ToString();
                    txtalt.Text = isi.Rows[i][2].ToString();
                    txtauthor.Text = isi.Rows[i][3].ToString();
                    txttranslator.Text = isi.Rows[i][4].ToString();
                    txteditor.Text = isi.Rows[i][5].ToString();
                    txtstatus.Text = isi.Rows[i][6].ToString();
                    txtraw.Text = isi.Rows[i][7].ToString();
                    rtxsynopsis.Text = isi.Rows[i][8].ToString();
                    pictureBox1.ImageLocation = isi.Rows[i][9].ToString();
                    txtlang.Text = isi.Rows[i][10].ToString();
                    rtxnote.Text = isi.Rows[i][11].ToString();
                    txtlink.Text = isi.Rows[i][12].ToString();
                    break;
                }
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Form1 a = new Form1();
            a.Show();
            this.Hide();
        }

        private void button1_Click(object sender, EventArgs e)
        {

            ArrayList nochapter = new ArrayList();

            foreach (string a in listBox1.Items)
            {
                nochapter.Add(a);

            }
            string dir = (Application.StartupPath + "\\output\\" + cbotitle.Text + "\\chapter" + cboch1.Text + "-" + cboch2.Text);
            FileHtml.makexhtml(cbotitle.Text, nochapter.ToArray(), dir, txttitle.Text, txtalt.Text, txtauthor.Text, txttranslator.Text, txteditor.Text, txtstatus.Text, txtraw.Text, rtxsynopsis.Text, txtlang.Text, rtxnote.Text, txtlink.Text);
            MessageBox.Show("finnish");
        }
        public void isicho()
        {
            int b;
            if (Int32.TryParse(cboch1.Text, out b) && Int32.TryParse(cboch2.Text, out b))
            {
                if (Convert.ToInt32(cboch1.Text) <= Convert.ToInt32(cboch2.Text))
                {
                    ArrayList no = new ArrayList();
                    var isi = Chapter.dapatchapter(cbotitle.Text);
                    listBox1.Items.Clear();
                    foreach (string a in isi)
                    {


                        if (System.Convert.ToInt32(a) >= Convert.ToInt32(cboch1.Text) && System.Convert.ToInt32(a) <= Convert.ToInt32(cboch2.Text))
                            no.Add(a);


                    }
                   int banyak = no.Count * no.Count;
                    ArrayList sortlist = new ArrayList();
                    while (banyak >= 0 && banyak > 1)
                    {
                        for (int i = 0; i <= no.Count - 2; i++)
                        {
                            
                            if (Convert.ToInt32(no[i].ToString())  >= Convert.ToInt32(no[i + 1].ToString()) ) 
                            {
                                int a = Convert.ToInt32(no[i].ToString());
                                no[i] = Convert.ToInt32(no[i + 1].ToString());
                                no[i + 1] = a;
                            }
                            
                        }
                        banyak--;


                    }
                    for (int i = 0; i <= no.Count - 1; i++)
                    {
                        listBox1.Items.Add(no[i].ToString());
                    }


                }



                else
                {
                    MessageBox.Show("Pilih Chapter Yang Benar!!");
                }


            }
        }
        private void cboch1_SelectedIndexChanged(object sender, EventArgs e)
        {
            cboch2.Text = "";
            isicho();
        }

        private void cboch2_SelectedIndexChanged(object sender, EventArgs e)
        {
            cboch2.Text = "";
            isicho();
        }
    }
}
