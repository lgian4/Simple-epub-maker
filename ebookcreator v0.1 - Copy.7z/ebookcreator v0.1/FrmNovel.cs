﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ebookcreator_v0._1
{
    public partial class FrmNovel : Form
    {
        string func;



        public FrmNovel()
        {
            InitializeComponent();
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            OpenFileDialog fd = new OpenFileDialog();
            fd.Title = "Buka Gambar";
            fd.Filter = "Jpeg FIle (*.jpg)|*.jpg";
            fd.ShowDialog();

            txtcover.Text = fd.FileName;

        }

        private void button1_Click(object sender, EventArgs e)
        {
           
        }
        public void isilbl()
        {
            try
            {
                cmdupdate.Enabled = true;
                cmddelete.Enabled = true;

                lblcode.Text = System.Convert.ToString(dg1.CurrentRow.Cells[0].Value);
                txttitle.Text = System.Convert.ToString(dg1.CurrentRow.Cells[1].Value);
                txtalt.Text = System.Convert.ToString(dg1.CurrentRow.Cells[2].Value);
                txtauthor.Text = System.Convert.ToString(dg1.CurrentRow.Cells[3].Value);
                txttrans.Text = System.Convert.ToString(dg1.CurrentRow.Cells[4].Value);
                txteditor.Text = System.Convert.ToString(dg1.CurrentRow.Cells[5].Value);
                txtstatus.Text = System.Convert.ToString(dg1.CurrentRow.Cells[6].Value);
                txtraw.Text = System.Convert.ToString(dg1.CurrentRow.Cells[7].Value);
                txtsynopsis.Text = System.Convert.ToString(dg1.CurrentRow.Cells[8].Value);
                txtcover.Text = System.Convert.ToString(dg1.CurrentRow.Cells[9].Value);
                txtlang.Text = System.Convert.ToString(dg1.CurrentRow.Cells[10].Value);
                txtnote.Text = System.Convert.ToString(dg1.CurrentRow.Cells[11].Value);
                txtlink.Text = System.Convert.ToString(dg1.CurrentRow.Cells[12].Value);

            }
            catch
            {
            }
        }
        private void start()
        {
            if (dg1.RowCount <= 0) { cmdupdate.Enabled = true; }
            cmddelete.Enabled = true;
            dg1.Enabled = true;
            cmdinsert.Enabled = true;
            txttitle.Enabled = true;
            cmdcancel.Enabled = false;
            cmdconfirm.Enabled = false;
            bsc1.DataSource = Novel.select();
            dg1.DataSource = bsc1;
            isilbl();

        }
        private void cmdinsert_Click(object sender, EventArgs e)
        {
            func = "I";
            cmddelete.Enabled = false;
            cmdupdate.Enabled = false;
            cmdinsert.Enabled = false;
            cmdconfirm.Enabled = true;
            cmdcancel.Enabled = true;
            dg1.Enabled = false;
            txttitle.Text = "";
            txtalt.Text = "";
            txtauthor.Text = "";
            txttrans.Text = "";
            txteditor.Text = "";
            txtstatus.Text = "";
            txtraw.Text = "";
            txtsynopsis.Text = "";
            txtcover.Text = "";
            txtlang.Text = "";
            txtnote.Text = "";
            txtlink.Text = "";
            lblcode.Text = "";
        }

        private void txtcover_TextChanged(object sender, EventArgs e)
        {
            pictureBox1.ImageLocation = txtcover.Text;
        }

        private void FrmNovel_Load(object sender, EventArgs e)
        {
            
           
            start();
           
        }

        private void txttitle_TextChanged(object sender, EventArgs e)
        {

            if (txttitle.Text.Trim() != "")
            {
                string hasil = "";
                string a = txttitle.Text.Trim();
                Array judul = a.Split();
                foreach (string b in judul)
                {
                    hasil += (b.Substring(0, 1).ToLower());
                }
                lblcode.Text = hasil;
            }




        }

        private void cmdconfirm_Click(object sender, EventArgs e)
        {
            pictureBox1.Load();
            if (func == "U") { pictureBox1.Image = null; }
            else
            {
                int i = 1;
                bool a = Novel.cekcode(lblcode.Text);
                while (a)
                {

                    Novel.cekcode(txttitle.Text += " " + i.ToString());
                    a = Novel.cekcode(lblcode.Text);
                    i++;
                }

            }
            Novel novel = new Novel(txttitle.Text, txtauthor.Text, txtsynopsis.Text, txtcover.Text, txtlang.Text, txtalt.Text, txttrans.Text, txteditor.Text, txtstatus.Text, txtraw.Text, txtnote.Text, txtlink.Text);


            novel.aksidata(func);
            start();
        }

        private void dg1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            isilbl();
        }

        private void dg1_SelectionChanged(object sender, EventArgs e)
        {
            isilbl();
        }

        private void cmddelete_Click(object sender, EventArgs e)
        {
            DialogResult dr = new DialogResult();
            dr = MessageBox.Show("Delete", "Are You Sure ?", MessageBoxButtons.OKCancel, MessageBoxIcon.Warning);
            if (dr == DialogResult.OK) Novel.deletedata(lblcode.Text);



        }

        private void cmdupdate_Click(object sender, EventArgs e)
        {
            isilbl();
            func = "U";
            cmddelete.Enabled = false;
            cmdupdate.Enabled = false;
            cmdinsert.Enabled = false;
            cmdconfirm.Enabled = true;
            cmdcancel.Enabled = true;
            dg1.Enabled = false;
            txttitle.Enabled = false;
        }

        private void cmdcancel_Click(object sender, EventArgs e)
        {
            start();
        }

        private void panel4_Paint(object sender, PaintEventArgs e)
        {

        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            Form1 a = new Form1();
            a.Show();
            this.Close();
        }
    }
}
