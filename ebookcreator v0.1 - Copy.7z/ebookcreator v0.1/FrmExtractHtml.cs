﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Aspose.Html;
namespace ebookcreator_v0._1
{
    public partial class FrmExtractHtml : Form
    {
        public FrmExtractHtml()
        {
            InitializeComponent();
        }

        private void FrmExtractHtml_Load(object sender, EventArgs e)
        {
            foreach (string a in Chapter.dapatcode()) { cbocode.Items.Add(a); }
            listBox1.Enabled = true;
            btnopen.Enabled = true;
            btncancel.Enabled = false;
            btnsimpan.Enabled = false;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            OpenFileDialog fd = new OpenFileDialog();
            fd.Title = "Buka Gambar";
            fd.Multiselect = true;
            fd.Filter = "Html FIle (*.html)|*.html|Mhtml FIle (*.mhtml)|*.mhtml";
            fd.ShowDialog();
            foreach (string a in fd.FileNames)
            {
                listBox1.Items.Add(a);
            }
        }

        private void btnback_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form1 a = new Form1();
            a.Show();
        }

        private void btnchapter_Click(object sender, EventArgs e)
        {
            this.Hide();
            frmchapter a = new frmchapter();
            a.Show();
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            textBox1.Text = listBox1.Text;
            textBox2.Text = listBox1.Text.Substring(listBox1.Text.LastIndexOf("\\") + 1);
        }

        private void btnopen_Click(object sender, EventArgs e)
        {

            if (txtno.Text.Trim() == "") { txtno.Text = "1"; }
            else
            {
                txtno.Text = Convert.ToString(Convert.ToInt32(txtno.Text) + 1);
            }
            listBox1.Enabled = false;
            btnopen.Enabled = false;
            btncancel.Enabled = true;
            btnsimpan.Enabled = true;
            if (textBox1.Text.Trim() == "") { MessageBox.Show("Pilih File yang mau diextract"); }
            else
            {
                richTextBox1.Text = FileHtml.openfile(textBox1.Text);
            }
        }

        private void btnsimpan_Click(object sender, EventArgs e)
        {
            FileHtml chapter = new FileHtml(cbocode.Text, Convert.ToInt32(txtno.Text), txttitle.Text, richTextBox1.Text);
            chapter.aksidata("I");
            if (listBox1.SelectedIndex != listBox1.Items.Count - 1)
            {
                listBox1.Enabled = true;
                btnopen.Enabled = true;
                btncancel.Enabled = false;
                btnsimpan.Enabled = false;
                listBox1.SelectedIndex = listBox1.SelectedIndex + 1;
                btnopen_Click(sender, e);
            }

        }
    }
}
