﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Windows.Forms;
using System.Data.OleDb;
using System.IO;
namespace ebookcreator_v0._1
{
    class Novel
    {
        //properties
        private string _code;

        public string Code
        {
            get { return _code; }

        }
        private string _title;

        public string Title
        {
            get { return _title; }
            set
            {
                string hasil = "";
                string a = value.Trim(); ;
                Array judul = a.Split();
                foreach (string b in judul)
                {
                    hasil += (b.Substring(0, 1).ToLower());
                }
                _code = hasil;
                _title = value.Trim();

                _cover = Application.StartupPath + "\\novel\\" + Code + "\\cover\\" + "cover.jpg";
            }
        }
        public static bool cekcode(string code)
        {
            conn = new OleDbConnection(Novel.koneksistring);
            conn.Open();
            comm = new OleDbCommand();
            comm.Connection = conn;
           comm.CommandText = "SELECT * FROM  tblnovel where code = '"+ code+"'";
            try
            {
                reader = comm.ExecuteReader();
                if (reader.HasRows == false)
                {
                    return false;

                }
                else
                {

                    return true;

                }
            }
            finally
            {
                reader.Close();
                conn.Close();
            }
           
           
           
        }

        private string _alttitle;

        public string Alttile
        {
            get { return _alttitle; }
            set
            {
                if (value.Trim() == "")
                {
                    _alttitle = "NaN";
                }
                else { _alttitle = value.Trim(); }


            }
        }
        private string _author;

        public string Author
        {
            get { return _author; }
            set
            {
                if (value.Trim() == "")
                {
                    _author = "NaN";
                }
                else { _author = value.Trim(); }
            }
        }
        private string _translator;

        public string Translator
        {
            get { return _translator; }
            set
            {
                if (value.Trim() == "")
                {
                    _translator = "NaN";
                }
                else { _translator = value.Trim(); }
            }
        }
        private string _editor;

        public string Editor
        {
            get { return _editor; }
            set
            {
                if (value.Trim() == "")
                {
                    _editor = "NaN";
                }
                else { _editor = value.Trim(); }
            }
        }
        private string _status;

        public string Status
        {
            get { return _status; }
            set
            {
                if (value.Trim() == "")
                {
                    _status = "NaN";
                }
                else { _status = value.Trim(); }
            }
        }
        private string _raw;

        public string Raw
        {
            get { return _raw; }
            set
            {
                if (value.Trim() == "")
                {
                    _raw = "NaN";
                }
                else { _raw = value.Trim(); }
            }
        }
        private string _synopsis;

        public string Synopsis
        {
            get { return _synopsis; }
            set
            {
                if (value.Trim() == "")
                {
                    _synopsis = "NaN";
                }
                else
                {
                    value = value.Replace("\'", "");
                    value = value.Replace("\"", "");
                    value = value.Replace("\\", "");
                    _synopsis = value.Trim();
                }
            }
        }
        private string _cover;
        public void newCover(string func, string newpath)
        {
            if (File.Exists(newpath) && func == "I")
            {

                Directory.CreateDirectory(Application.StartupPath + "\\novel\\" + Code + "\\cover\\");

                File.Copy(newpath, Application.StartupPath + "\\novel\\" + Code + "\\cover\\" + "cover.jpg", true);


            }
        }
        public void updateCover(string func, string newpath, string code)
        {
            if (func == "U")
            {
                string oldpath = "";
                conn = new OleDbConnection(Novel.koneksistring);
                conn.Open();
                comm = new OleDbCommand();
                comm.Connection = conn;
                string query = "SELECT cover FROM  tblnovel where code = ";
                query += "'" + code + "'";
                comm.CommandText = query;
                reader = comm.ExecuteReader();
                if (reader.HasRows == false)
                {
                    MessageBox.Show("Errorr");

                }
                else
                {
                    reader.Read();
                    oldpath = reader.GetValue(0).ToString();
                    reader.Close(); if (File.Exists(newpath))
                    {
                        if (oldpath != newpath)
                        {

                            Directory.CreateDirectory(Application.StartupPath + "\\novel\\" + Code + "\\cover\\");
                            File.Delete(Application.StartupPath + "\\novel\\" + Code + "\\cover\\" + "cover.jpg");
                            File.Copy(newpath, Application.StartupPath + "\\novel\\" + Code + "\\cover\\" + "cover.jpg", true);
                        }

                    }
                }
                conn.Close();


            }
        }
        public string Cover
        {
            get { return _cover; }

        }
        private string _language;

        public string Language
        {
            get { return _language; }
            set
            {
                if (value.Trim() == "")
                {
                    _language = "NaN";
                }
                else { _language = value.Trim(); }
            }
        }
        private string _note;

        public string Note
        {
            get { return _note; }
            set
            {
                if (value.Trim() == "")
                {
                    _note = "NaN";
                }
                else { _note = value.Trim(); }
            }
        }
        private string _link;

        public string Link
        {
            get { return _link; }
            set
            {
                if (value.Trim() == "")
                {
                    _link = "NaN";
                }
                else { _link = value.Trim(); }
            }
        }

        // constructor
        public Novel(string title, string author, string synopsis, string cover, string language, string alttitle = "-", string translator = "-", string editor = "-", string status = "-", string raw = "-", string note = "-", string link = "#")
        {


            Title = title;
            Author = author;
            Synopsis = synopsis;
            if (File.Exists(Application.StartupPath + "\\novel\\" + Code + "\\cover\\" + "cover.jpg"))
            {
                updateCover("U", cover, Code);

            }
            else if (!File.Exists(Application.StartupPath + "\\novel\\" + Code + "\\cover\\" + "cover.jpg"))
            {
                newCover("I", cover);
            }

            Language = language;
            Alttile = alttitle;
            Translator = translator;
            Editor = editor;
            Status = status;
            Raw = raw;
            Note = note;
            Link = link;


        }







        private static string _koneksistring = "provider=microsoft.ace.oledb.12.0.0; data source=" + Application.StartupPath + "//epub1.accdb";
        internal static OleDbConnection conn = new OleDbConnection();
        internal static OleDbCommand comm = new OleDbCommand();
        internal static OleDbDataAdapter adap = new OleDbDataAdapter();
        internal static OleDbDataReader reader;
        internal static DataTable tabel = new DataTable();

        internal static string koneksistring { get { return _koneksistring; } }

        // ambil isi data table yang diinginkan
        public static DataTable select()
        {
            conn = new OleDbConnection(Novel.koneksistring);
            conn.Open();
            comm = new OleDbCommand();
            comm.Connection = conn;
            comm.CommandText = "SELECT * FROM  tblnovel";
            reader = comm.ExecuteReader();
            if (reader.HasRows == false)
            {
                MessageBox.Show("table  is empty");

            }
            else
            {
                reader.Close();
                adap = new OleDbDataAdapter(comm);
                tabel = new DataTable();
                adap.Fill(tabel);

            }
            conn.Close();
            return tabel;
        }




        public void aksidata(string func)
        {
            OleDbParameter pcode = new OleDbParameter("@code", OleDbType.VarChar);
            OleDbParameter ptitle = new OleDbParameter("@title", OleDbType.VarChar);
            OleDbParameter palt = new OleDbParameter("@palt", OleDbType.VarChar);
            OleDbParameter pauthor = new OleDbParameter("@author", OleDbType.VarChar);
            OleDbParameter ptrans = new OleDbParameter("@trans", OleDbType.VarChar);
            OleDbParameter peditor = new OleDbParameter("@editor", OleDbType.VarChar);
            OleDbParameter pstatus = new OleDbParameter("@status", OleDbType.VarChar);
            OleDbParameter praw = new OleDbParameter("@raw", OleDbType.VarChar);
            OleDbParameter psynopsis = new OleDbParameter("@synopsis", OleDbType.LongVarChar);
            OleDbParameter pcover = new OleDbParameter("@cover", OleDbType.VarChar);
            OleDbParameter plang = new OleDbParameter("@lang", OleDbType.VarChar);
            OleDbParameter pnote = new OleDbParameter("@note", OleDbType.LongVarChar);
            OleDbParameter plink = new OleDbParameter("@link", OleDbType.VarChar);
            ptitle.Value = Title;
            pcode.Value = Code;
            palt.Value = Alttile;
            pauthor.Value = Author;
            ptrans.Value = Translator;
            peditor.Value = Editor;
            pstatus.Value = Status;
            praw.Value = Raw;
            psynopsis.Value = Synopsis;
            pcover.Value = Cover;
            plang.Value = Language;
            pnote.Value = Note;
            plink.Value = Link;

            OleDbConnection conn = new OleDbConnection(koneksistring);
            conn.Open();
            OleDbCommand comm = new OleDbCommand();
            comm.Connection = conn;
            if (func == "I")
            {

                comm.CommandText = "INSERT INTO tblnovel Values(@code,@title,@alt,@author,@trans,@editor,@status,@raw,@synopsis,@cover,@lang,@note,@link)";
                comm.Parameters.Add(pcode);
                comm.Parameters.Add(ptitle);
                comm.Parameters.Add(palt);
                comm.Parameters.Add(pauthor);
                comm.Parameters.Add(ptrans);
                comm.Parameters.Add(peditor);
                comm.Parameters.Add(pstatus);
                comm.Parameters.Add(praw);
                comm.Parameters.Add(psynopsis);
                comm.Parameters.Add(pcover);
                comm.Parameters.Add(plang);
                comm.Parameters.Add(pnote);
                comm.Parameters.Add(plink);



            }
            else
            {

                comm.CommandText = @"UPDATE tblnovel SET tblnovel.title = @title, tblnovel.alttitle =@alt, tblnovel.author=@author,tblnovel.translator=@trans,tblnovel.editor= @editor,tblnovel.status =@staus, tblnovel.raw = @raw,tblnovel.synopsis=@synopsis,tblnovel.[language]=@lang,tblnovel.[note]=@note,  tblnovel.link= @link  WHERE (((tblnovel.code) = @code));";
                comm.CommandTimeout = 10000;
                comm.Parameters.Add(ptitle);
                comm.Parameters.Add(palt);
                comm.Parameters.Add(pauthor);
                comm.Parameters.Add(ptrans);
                comm.Parameters.Add(peditor);
                comm.Parameters.Add(pstatus);
                comm.Parameters.Add(praw);
                comm.Parameters.Add(psynopsis);

                comm.Parameters.Add(plang);
                comm.Parameters.Add(pnote);
                comm.Parameters.Add(plink);
                comm.Parameters.Add(pcode);
            }
            MessageBox.Show(comm.ExecuteNonQuery().ToString() + "Row Changed");

            conn.Close();
        }
        public static void deletedata(string code)
        {
            OleDbConnection conn = new OleDbConnection(koneksistring);
            conn.Open();
            OleDbCommand comm = new OleDbCommand();
            comm.Connection = conn;

            comm.CommandText = "DELETE FROM tblnovel WHERE code = " + code;

            comm.ExecuteScalar();

            conn.Close();
        }
    }
}
