﻿namespace ebookcreator_v0._1
{
    partial class frmchapter
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.dg1 = new System.Windows.Forms.DataGridView();
            this.panel3 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel4 = new System.Windows.Forms.Panel();
            this.erp1 = new System.Windows.Forms.ErrorProvider(this.components);
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel5 = new System.Windows.Forms.Panel();
            this.rtxchapter = new System.Windows.Forms.RichTextBox();
            this.panel6 = new System.Windows.Forms.Panel();
            this.txtno = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.txttitle = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.txtfile = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.lblid = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.cbocode = new System.Windows.Forms.ComboBox();
            this.panel7 = new System.Windows.Forms.Panel();
            this.button1 = new System.Windows.Forms.Button();
            this.cmdinsert = new System.Windows.Forms.Button();
            this.cmdupdate = new System.Windows.Forms.Button();
            this.cmddelete = new System.Windows.Forms.Button();
            this.cmdcancel = new System.Windows.Forms.Button();
            this.cmdconfirm = new System.Windows.Forms.Button();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.bsc1 = new System.Windows.Forms.BindingSource(this.components);
            this.button2 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dg1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.erp1)).BeginInit();
            this.panel1.SuspendLayout();
            this.panel5.SuspendLayout();
            this.panel6.SuspendLayout();
            this.panel7.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bsc1)).BeginInit();
            this.SuspendLayout();
            // 
            // dg1
            // 
            this.dg1.AllowUserToAddRows = false;
            this.dg1.AllowUserToDeleteRows = false;
            this.dg1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dg1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dg1.Location = new System.Drawing.Point(523, 26);
            this.dg1.MultiSelect = false;
            this.dg1.Name = "dg1";
            this.dg1.ReadOnly = true;
            this.dg1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dg1.Size = new System.Drawing.Size(338, 599);
            this.dg1.TabIndex = 34;
            this.dg1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dg1_CellContentClick);
            this.dg1.SelectionChanged += new System.EventHandler(this.dg1_SelectionChanged);
            // 
            // panel3
            // 
            this.panel3.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel3.Location = new System.Drawing.Point(523, 625);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(338, 32);
            this.panel3.TabIndex = 32;
            // 
            // panel2
            // 
            this.panel2.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel2.Location = new System.Drawing.Point(523, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(338, 26);
            this.panel2.TabIndex = 31;
            // 
            // panel4
            // 
            this.panel4.Dock = System.Windows.Forms.DockStyle.Right;
            this.panel4.Location = new System.Drawing.Point(861, 0);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(16, 657);
            this.panel4.TabIndex = 33;
            // 
            // erp1
            // 
            this.erp1.ContainerControl = this;
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.panel5);
            this.panel1.Controls.Add(this.panel6);
            this.panel1.Controls.Add(this.panel7);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(523, 657);
            this.panel1.TabIndex = 35;
            // 
            // panel5
            // 
            this.panel5.Controls.Add(this.rtxchapter);
            this.panel5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel5.Location = new System.Drawing.Point(0, 85);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(523, 523);
            this.panel5.TabIndex = 41;
            // 
            // rtxchapter
            // 
            this.rtxchapter.Dock = System.Windows.Forms.DockStyle.Fill;
            this.rtxchapter.Location = new System.Drawing.Point(0, 0);
            this.rtxchapter.Name = "rtxchapter";
            this.rtxchapter.Size = new System.Drawing.Size(523, 523);
            this.rtxchapter.TabIndex = 40;
            this.rtxchapter.Text = "";
            // 
            // panel6
            // 
            this.panel6.Controls.Add(this.txtno);
            this.panel6.Controls.Add(this.label5);
            this.panel6.Controls.Add(this.txttitle);
            this.panel6.Controls.Add(this.label4);
            this.panel6.Controls.Add(this.label1);
            this.panel6.Controls.Add(this.txtfile);
            this.panel6.Controls.Add(this.label3);
            this.panel6.Controls.Add(this.label2);
            this.panel6.Controls.Add(this.lblid);
            this.panel6.Controls.Add(this.label10);
            this.panel6.Controls.Add(this.cbocode);
            this.panel6.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel6.Location = new System.Drawing.Point(0, 0);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(523, 85);
            this.panel6.TabIndex = 42;
            // 
            // txtno
            // 
            this.txtno.Location = new System.Drawing.Point(353, 29);
            this.txtno.Name = "txtno";
            this.txtno.Size = new System.Drawing.Size(58, 20);
            this.txtno.TabIndex = 43;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(185, 9);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(27, 13);
            this.label5.TabIndex = 42;
            this.label5.Text = "Title";
            // 
            // txttitle
            // 
            this.txttitle.Location = new System.Drawing.Point(177, 29);
            this.txttitle.Name = "txttitle";
            this.txttitle.Size = new System.Drawing.Size(170, 20);
            this.txttitle.TabIndex = 41;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(229, 65);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(44, 13);
            this.label4.TabIndex = 40;
            this.label4.Text = "Chapter";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(18, 13);
            this.label1.TabIndex = 14;
            this.label1.Text = "ID";
            // 
            // txtfile
            // 
            this.txtfile.Location = new System.Drawing.Point(417, 29);
            this.txtfile.Name = "txtfile";
            this.txtfile.Size = new System.Drawing.Size(100, 20);
            this.txtfile.TabIndex = 39;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(62, 9);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(35, 13);
            this.label3.TabIndex = 17;
            this.label3.Text = "Novel";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(416, 9);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(23, 13);
            this.label2.TabIndex = 38;
            this.label2.Text = "File";
            // 
            // lblid
            // 
            this.lblid.BackColor = System.Drawing.Color.White;
            this.lblid.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblid.Location = new System.Drawing.Point(11, 30);
            this.lblid.Name = "lblid";
            this.lblid.Size = new System.Drawing.Size(33, 22);
            this.lblid.TabIndex = 15;
            this.lblid.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(349, 9);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(61, 13);
            this.label10.TabIndex = 35;
            this.label10.Text = "No Chpater";
            // 
            // cbocode
            // 
            this.cbocode.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbocode.FormattingEnabled = true;
            this.cbocode.Location = new System.Drawing.Point(50, 30);
            this.cbocode.Name = "cbocode";
            this.cbocode.Size = new System.Drawing.Size(121, 21);
            this.cbocode.TabIndex = 36;
            this.cbocode.SelectedIndexChanged += new System.EventHandler(this.cbocode_SelectedIndexChanged);
            // 
            // panel7
            // 
            this.panel7.Controls.Add(this.button2);
            this.panel7.Controls.Add(this.button1);
            this.panel7.Controls.Add(this.cmdinsert);
            this.panel7.Controls.Add(this.cmdupdate);
            this.panel7.Controls.Add(this.cmddelete);
            this.panel7.Controls.Add(this.cmdcancel);
            this.panel7.Controls.Add(this.cmdconfirm);
            this.panel7.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel7.Location = new System.Drawing.Point(0, 608);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(523, 49);
            this.panel7.TabIndex = 43;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(445, 3);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(72, 43);
            this.button1.TabIndex = 21;
            this.button1.Text = "Back";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // cmdinsert
            // 
            this.cmdinsert.Location = new System.Drawing.Point(10, 3);
            this.cmdinsert.Name = "cmdinsert";
            this.cmdinsert.Size = new System.Drawing.Size(63, 43);
            this.cmdinsert.TabIndex = 9;
            this.cmdinsert.Text = "Insert";
            this.cmdinsert.UseVisualStyleBackColor = true;
            this.cmdinsert.Click += new System.EventHandler(this.cmdinsert_Click);
            // 
            // cmdupdate
            // 
            this.cmdupdate.Location = new System.Drawing.Point(79, 3);
            this.cmdupdate.Name = "cmdupdate";
            this.cmdupdate.Size = new System.Drawing.Size(63, 43);
            this.cmdupdate.TabIndex = 10;
            this.cmdupdate.Text = "Update";
            this.cmdupdate.UseVisualStyleBackColor = true;
            this.cmdupdate.Click += new System.EventHandler(this.cmdupdate_Click);
            // 
            // cmddelete
            // 
            this.cmddelete.Location = new System.Drawing.Point(146, 3);
            this.cmddelete.Name = "cmddelete";
            this.cmddelete.Size = new System.Drawing.Size(66, 43);
            this.cmddelete.TabIndex = 11;
            this.cmddelete.Text = "Delete";
            this.cmddelete.UseVisualStyleBackColor = true;
            this.cmddelete.Click += new System.EventHandler(this.cmddelete_Click);
            // 
            // cmdcancel
            // 
            this.cmdcancel.Enabled = false;
            this.cmdcancel.Location = new System.Drawing.Point(369, 3);
            this.cmdcancel.Name = "cmdcancel";
            this.cmdcancel.Size = new System.Drawing.Size(70, 43);
            this.cmdcancel.TabIndex = 13;
            this.cmdcancel.Text = "Cancel";
            this.cmdcancel.UseVisualStyleBackColor = true;
            // 
            // cmdconfirm
            // 
            this.cmdconfirm.Enabled = false;
            this.cmdconfirm.Location = new System.Drawing.Point(291, 3);
            this.cmdconfirm.Name = "cmdconfirm";
            this.cmdconfirm.Size = new System.Drawing.Size(72, 43);
            this.cmdconfirm.TabIndex = 12;
            this.cmdconfirm.Text = "Confirm";
            this.cmdconfirm.UseVisualStyleBackColor = true;
            this.cmdconfirm.Click += new System.EventHandler(this.cmdconfirm_Click);
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "openFileDialog1";
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(218, 5);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(67, 39);
            this.button2.TabIndex = 22;
            this.button2.Text = "To HTML";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // frmchapter
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(877, 657);
            this.ControlBox = false;
            this.Controls.Add(this.dg1);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.panel1);
            this.Name = "frmchapter";
            this.Text = "Chapter";
            this.Load += new System.EventHandler(this.frmchapter_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dg1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.erp1)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel5.ResumeLayout(false);
            this.panel6.ResumeLayout(false);
            this.panel6.PerformLayout();
            this.panel7.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.bsc1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView dg1;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.ErrorProvider erp1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.TextBox txtfile;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox cbocode;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label lblid;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button cmdcancel;
        private System.Windows.Forms.Button cmdconfirm;
        private System.Windows.Forms.Button cmddelete;
        private System.Windows.Forms.Button cmdupdate;
        private System.Windows.Forms.Button cmdinsert;
        private System.Windows.Forms.BindingSource bsc1;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.RichTextBox rtxchapter;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txttitle;
        private System.Windows.Forms.TextBox txtno;
        private System.Windows.Forms.Button button2;
    }
}